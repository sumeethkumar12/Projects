import styles from "./page.module.css";
import ListPosts from "./posts/page";

export default function Home() {

  return (
    <div>
      <ListPosts />
    </div>
  );
}
