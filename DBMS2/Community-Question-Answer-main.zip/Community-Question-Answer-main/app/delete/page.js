import React from 'react'

function page() {
  return (
    <div>deleted</div>
  )
}

export default page